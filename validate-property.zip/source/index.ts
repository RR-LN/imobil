import { z } from 'npm:zod@3.21.4';

// Zod schema
const propertySchema = z.object({
  title: z.string().min(5).max(100),
  description: z.string().min(20).max(2000),
  price: z.number().positive().max(1_000_000_000),
  city: z.string().min(2).max(50),
  type: z.enum(['house', 'land', 'apartment']),
  transaction: z.enum(['sale', 'rent']),
  bedrooms: z.number().optional(),
  bathrooms: z.number().optional(),
  area_m2: z.number().optional(),
  parking: z.number().optional(),
  location: z.string().optional(),
  images: z.array(z.string().url()).max(20)
});

console.info('validate-property function starting');

Deno.serve(async (req: Request) => {
  const url = new URL(req.url);
  if (req.method !== 'POST' || url.pathname !== '/validate-property') {
    return new Response(JSON.stringify({ success: false, message: 'Not Found' }), { status: 404, headers: { 'Content-Type': 'application/json' } });
  }

  // Verify Authorization header (Bearer JWT) presence
  const auth = req.headers.get('authorization');
  if (!auth || !auth.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ success: false, errors: [{ field: 'authorization', message: 'Missing or invalid Authorization header' }] }), { status: 401, headers: { 'Content-Type': 'application/json' } });
  }

  // Note: Full JWT verification against Supabase is handled by platform if configured.

  let body: any;
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ success: false, errors: [{ field: 'body', message: 'Invalid JSON' }] }), { status: 400, headers: { 'Content-Type': 'application/json' } });
  }

  if (!body || typeof body !== 'object' || !body.data) {
    return new Response(JSON.stringify({ success: false, errors: [{ field: 'data', message: 'Missing data object' }] }), { status: 400, headers: { 'Content-Type': 'application/json' } });
  }

  const parse = propertySchema.safeParse(body.data);
  if (!parse.success) {
    const errors = parse.error.errors.map(err => ({ field: err.path.join('.') || 'data', message: err.message }));
    return new Response(JSON.stringify({ success: false, errors }), { status: 400, headers: { 'Content-Type': 'application/json' } });
  }

  return new Response(JSON.stringify({ success: true, data: parse.data }), { status: 200, headers: { 'Content-Type': 'application/json' } });
});
